package com.mziuri;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

public class MessageValidatorTest {

    private static MessageValidatorTest instance;

    public static MessageValidatorTest getInstance() {
        return instance;
    }

    @Test
    void testValidMessage() {
        MessageValidatorTest validator = MessageValidatorTest.getInstance();

        Assertions.assertTrue(validator.testValidMessage("Hello, this is a valid message."));

    }

    private boolean testValidMessage(String s) {
        return false;
    }

    @Test
    void testInvalidMessage() {
        MessageValidatorTest validator = MessageValidatorTest.getInstance();

        Assertions.assertFalse(validator.testInvalidMessage("This message contains a forbidden character \n"));

    }

    private boolean testInvalidMessage(String s) {
        return false;
    }
}

