package com.mziuri;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


@WebServlet("/message")
public class Message extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        // Get the parameters from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Authenticate user (you may want to use a more secure authentication mechanism)
        if (authenticateUser(username, password)) {
            // Get the user's messages from the database
            String userMessages = getUserMessages(username);
            out.println(userMessages);
        } else {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.println("Unauthorized");
        }

        out.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        // Get parameters from request
        String senderUsername = request.getParameter("username");
        String message = request.getParameter("message");

        // Check sender user exists
        if (userExists(senderUsername) && !message.contains("\n")) {
            // Get the receiver username
            String receiverUsername = request.getParameter("receiver");

            // Store message in database
            storeMessage(senderUsername, receiverUsername, message);

            out.println("Message sent successfully");
        } else {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.println("Forbidden");
        }

        out.close();
    }

    private boolean authenticateUser(String username, String password) {
        // Implement your authentication logic (e.g., check against the database)
        // Return true if authentication is successful, else return false
        // This is a simplified example, and you should use a secure authentication mechanism
        // such as hashing passwords and checking against hashed values in the database.
        // For simplicity, we're using plain text passwords here.
        return true;
    }

    private String getUserMessages(String username) {
        // Retrieve user messages from the database
        StringBuilder result = new StringBuilder();
        try (Connection connection = DatabaseManager.getInstance().getConnection()) {
            String sql = "SELECT content FROM messages WHERE receiver_id = (SELECT id FROM users WHERE username = ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, username);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        result.append(resultSet.getString("content")).append("\n");
                    }
                }
            }
        } catch (SQLException e) {      e.printStackTrace();
        }
        return result.toString();
    }

    private boolean userExists(String username) {
        // Check if user exists in database
        try (Connection connection = DatabaseManager.getInstance().getConnection()) {
            String sql = "SELECT COUNT(*) AS count FROM users WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, username);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next() && resultSet.getInt("count") > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void storeMessage(String senderUsername, String receiverUsername, String message) {
        // Store message in the database
        try (Connection connection = DatabaseManager.getInstance().getConnection()) {
            String sql = "INSERT INTO messages (sender_id, receiver_id, content) VALUES ((SELECT id FROM users WHERE username = ?), (SELECT id FROM users WHERE username = ?), ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, senderUsername);
                preparedStatement.setString(2, receiverUsername);
                preparedStatement.setString(3, message);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
