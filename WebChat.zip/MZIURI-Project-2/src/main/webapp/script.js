
  async function sendRequest() {
      // Constructing the URL
      var url = webserverName + servletUrl + '?param1=param1Value' + '&param2=param2Value';

      var method = "POST";

      try {
          var response = await fetch(url, { method: method });

          if (response.ok) {
              var responseBody = await response.text();

              var div = document.getElementById("some-div-id");

              div.innerHTML = responseBody;
          } else {

              console.error("Request failed with status:", response.status);
          }
      } catch (error) {
          console.error("Error:", error);
      }
  }


  sendRequest();









